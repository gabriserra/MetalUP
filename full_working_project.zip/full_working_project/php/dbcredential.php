<?php
//contain db credential to create connection
$dbUsername = "root";
$dbPassword = "password";
$dbName = "metalup";
$dbHost = "localhost";

?>